#!/bin/bash

echo "* * * * * mysqldump -uroot -p123123123 --host=172.50.1.4 --port=3306 --single-transaction=TRUE --all-databases > /scripts/backup.sql
#weiter" > job
crontab job
cron -f
